package pro.realis.lab.jboss.foodify.ejb;


import pro.realis.lab.jboss.foodify.model.Order;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;


import java.util.logging.Logger;

/*
@MessageDriven(mappedName = "OrderQueue",activationConfig =
        {
                @ActivationConfigProperty(propertyName="messagingType", propertyValue="javax.jms.MessageListener"),
                @ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue"),
                @ActivationConfigProperty(propertyName="destination", propertyValue="java:/jms/queue/orders"),
                @ActivationConfigProperty(propertyName = "maxSession", propertyValue = "30")})
*/
public class Kitchen implements MessageListener {

    private Logger logger = Logger.getLogger(Kitchen.class.getName());

    @Override
    public void onMessage(Message message) {
        try {
            /* JMS 2.0
            Order o = message.getBody(Order.class);
            */
            Order o = null;
            if (message instanceof ObjectMessage) {
                o = (Order) ((ObjectMessage) message).getObject();
            }

            logger.info("order received: " + o);
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}