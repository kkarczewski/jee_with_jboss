package pro.realis.lab.jboss.foodify.ejb;

import pro.realis.lab.jboss.foodify.api.MealsService;
import pro.realis.lab.jboss.foodify.api.MealsServiceRemote;
import pro.realis.lab.jboss.foodify.dao.MealsDAO;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import javax.jws.WebService;
import java.util.List;
import java.util.logging.Logger;

@Stateless
@Local(MealsService.class)
@Remote(MealsServiceRemote.class)
@WebService
@Alternative
public class MealsServiceEjb implements MealsService, MealsServiceRemote {

    private Logger logger = Logger.getLogger(MealsServiceEjb.class.getName());

    @Inject
    private MealsDAO mealsDAO;

    @Resource
    private SessionContext ctxt;

    public List<Restaurant> getRestaurants() {
        logger.info("fetching restaurant list from data access object. session: " + ctxt.getCallerPrincipal() + " " + ctxt.getContextData());
        return mealsDAO.getAllRestaurants();
    }

    public Restaurant getRestaurant(Long id) {
        return mealsDAO.getRestaurantById(id);
    }

    public List<Meal> getMealsForRestaurant(Long rId) {
        return mealsDAO.getMealsByRestaurant(mealsDAO.getRestaurantById(rId));
    }

    public Meal getMealById(Long mId) {
        return mealsDAO.getMealsById(mId);
    }

    public Restaurant addRestaurant(Restaurant r) {
        return mealsDAO.addRestaurant(r);
    }

    public Meal addMeal(Restaurant r, Meal m) {
        logger.info("adding meal [" + m.getId() + " | " + m.getName() + " | " + m.getPrice() + "] to restaurant " + r.getId());
        m.setRestaurant(getRestaurant(r.getId()));
        return mealsDAO.addMeal(m);
    }

}
