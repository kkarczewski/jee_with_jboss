package pro.realis.lab.jboss.foodify.client;

import pro.realis.lab.jboss.foodify.api.MealsServiceRemote;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Properties;

/**
 * Created by xdzm on 2015-10-27.
 */
public class MealsClient {

    private static final String JNDI_NAME = "java:module/MealsServiceEjb!MealsServiceRemote";


    //private static final String JNDI_NAME = "java:global/meals/meals-ejb/MealsServiceEjb!MealsServiceRemote";

    public static void main(String[] args) throws Exception {

        Properties jndiProperties=new Properties();
        jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
        jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        jndiProperties.put(Context.PROVIDER_URL, "remote://localhost:4447/");
        jndiProperties.put("jboss.naming.client.ejb.context", true);
        jndiProperties.put("org.jboss.ejb.client.scoped.context", "true");

        Context ctx=new InitialContext(jndiProperties);

        MealsServiceRemote ms = (MealsServiceRemote) ctx.lookup(args[0]);

        Restaurant r = new Restaurant(99l, "Pyrek", "http://vignette4.wikia.nocookie.net/poznan/images/c/c9/Pyry.jpg", "Poznan", "sw. Marcina 12/34");
        r = ms.addRestaurant(r);

        System.out.println("restaurant added: " + r);


    }

}






