package pro.realis.lab.jboss.foodify.dao;

import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import java.util.List;

/**
 * Created by xdzm on 2015-10-14.
 */
public interface MealsDAO {

    List<Restaurant> getAllRestaurants();

    Restaurant getRestaurantById(Long id);

    List<Meal> getMealsByRestaurant(Restaurant r);

    Meal getMealsById(Long mId);

    Restaurant addRestaurant(Restaurant r);

    Meal addMeal(Meal m);

}
