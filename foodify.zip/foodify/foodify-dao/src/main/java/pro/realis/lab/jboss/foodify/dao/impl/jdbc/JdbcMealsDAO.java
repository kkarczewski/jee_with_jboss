package pro.realis.lab.jboss.foodify.dao.impl.jdbc;

import pro.realis.lab.jboss.foodify.dao.MealsDAO;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.annotation.Resource;
import javax.enterprise.inject.Alternative;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JdbcMealsDAO implements MealsDAO {

    public static final Logger logger = Logger.getLogger(JdbcMealsDAO.class.getName());

    public static final String SELECT_ALL_RESTAURANTS = "select r.id as restaurant_id, r.city as restaurant_city, r.logoimage as restaurant_logo, " +
            "r.name as restaurant_name, r.streetandnumber as street_and_number " +
            "from RESTAURANT r";

    public static final String SELECT_RESTAURANT_BY_ID = "select r.id as restaurant_id, r.city as restaurant_city, r.logoimage as restaurant_logo, " +
            "r.name as restaurant_name, r.streetandnumber as street_and_number " +
            "from RESTAURANT r where id=?";


    public static final String SELECT_MEAL_BY_ID = "select m.id as meal_id, " +
            "m.name as meal_name, m.price as meal_price," +
            "r.id as restaurant_id, r.city as restaurant_city, r.logoimage as restaurant_logo, " +
            "r.name as restaurant_name, r.streetandnumber  as street_and_number " +
            "from MEAL m, RESTAURANT r where m.restaurant_id = r.id and m.id = ?";
    public static final String SELECT_MEALS_BY_RESTAURANT = "select m.id as meal_id, " +
            "m.name as meal_name, m.price as meal_price," +
            "r.id as restaurant_id, r.city as restaurant_city, r.logoimage as restaurant_logo,  " +
            "r.name as restaurant_name, r.streetandnumber  as street_and_number " +
            "from MEAL m, RESTAURANT r where m.restaurant_id = r.id and r.id=?";


    public static final String INSERT_RESTAURANT_MEAL = "insert into MEAL " +
            "(id,name,price,restaurant_id) value(?, ?, ?, ?)";

    @Resource( lookup = "jdbc/Foodify")
    private DataSource dataSource;

    public List<Restaurant> getAllRestaurants() {
        List<Restaurant> restaurants = new ArrayList<Restaurant>();
        try(Connection con = this.dataSource.getConnection();
            Statement statement = con.createStatement();) {
            ResultSet resultSet = statement.executeQuery(SELECT_ALL_RESTAURANTS);
            while (resultSet.next()) {
                restaurants.add(mapRestaurant(resultSet));
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
        return restaurants;
    }

    public Restaurant getRestaurantById(Long id) {
        Restaurant r = null;
        try(Connection con = this.dataSource.getConnection();
            PreparedStatement prpstm = con.prepareStatement(SELECT_RESTAURANT_BY_ID);) {
            prpstm.setLong(1, id);
            ResultSet rs = prpstm.executeQuery();
            if(rs.next()) {
                r = mapRestaurant(rs);
            }

        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
        return r;
    }

    public List<Meal> getMealsByRestaurant(Restaurant r) {
        List<Meal> meals = new ArrayList<>();
        try (Connection con = this.dataSource.getConnection();
             PreparedStatement prpstm = con.prepareStatement(SELECT_MEALS_BY_RESTAURANT);) {
            prpstm.setLong(1, r.getId());
            ResultSet rs = prpstm.executeQuery();
            while(rs.next()){
                meals.add(mapMeal(rs, r));
            }

        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
        return meals;
    }

    public Meal getMealsById(Long mId) {
        Meal meal = null;
        try(Connection con = this.dataSource.getConnection();
            PreparedStatement prpstm = con.prepareStatement(SELECT_MEAL_BY_ID);) {
            prpstm.setLong(1, mId);
            ResultSet rs = prpstm.executeQuery();
            if(rs.next()){
                meal = mapMeal(rs, null);
            }

        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
        return meal;
    }

    public Restaurant addRestaurant(Restaurant r) {
        return null;
    }

    public Meal addMeal(Meal m) {

        try(Connection con = this.dataSource.getConnection();
            PreparedStatement prpstm = con.prepareStatement(INSERT_RESTAURANT_MEAL);) {
            prpstm.setLong(1, m.getId());
            prpstm.setString(2, m.getName());
            prpstm.setInt(3, m.getPrice());
            prpstm.setLong(4, m.getRestaurant().getId());
            prpstm.executeUpdate();

            m = getMealsById(m.getId());

        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getLocalizedMessage(), ex);
        }
        return m;
    }

    private Restaurant mapRestaurant(ResultSet rs) throws SQLException {
        Restaurant r = new Restaurant();
        r.setId(rs.getLong("restaurant_id"));
        r.setName(rs.getString("restaurant_name"));
        r.setLogoImage(rs.getString("restaurant_logo"));
        r.setCity(rs.getString("restaurant_city"));
        r.setStreetAndNumber(rs.getString("street_and_number"));
        return r;
    }

    private Meal mapMeal(ResultSet rs, Restaurant r) throws SQLException {
        Meal m = new Meal();
        m.setId(rs.getLong("meal_id"));
        m.setName(rs.getString("meal_name"));
        m.setPrice(rs.getInt("meal_price"));
        if(r==null){
            r = mapRestaurant(rs);
        }
        m.setRestaurant(r);

        return m;
    }

}



