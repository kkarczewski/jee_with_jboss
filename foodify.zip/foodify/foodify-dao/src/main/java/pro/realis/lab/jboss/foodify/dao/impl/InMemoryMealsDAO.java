package pro.realis.lab.jboss.foodify.dao.impl;

import pro.realis.lab.jboss.foodify.model.InitData;
import pro.realis.lab.jboss.foodify.dao.MealsDAO;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.enterprise.inject.Alternative;
import java.util.List;
import java.util.logging.Logger;

@Alternative
public class InMemoryMealsDAO implements MealsDAO {

    private Logger logger = Logger.getLogger(InMemoryMealsDAO.class.getName());



    private List<Restaurant> restaurants = InitData.getInitialRestaurantList();

    public List<Restaurant> getAllRestaurants() {
        logger.info("fetching predefined list of restaurants");
        return restaurants;
    }

    public Restaurant getRestaurantById(Long id) {
        for(Restaurant r: restaurants){
            if(r.getId().equals(id)){
                return r;
            }
        }
        return null;
    }

    public List<Meal> getMealsByRestaurant(Restaurant r) {
        return r.getMeals();
    }

    public Meal getMealsById(Long mId) {
        for(Restaurant r: restaurants){
            for(Meal m: r.getMeals()){
                if(m.getId().equals(mId)){
                    return m;
                }
            }
        }
        return null;
    }

    public Restaurant addRestaurant(Restaurant r) {
        Long max = 0L;
        for(Restaurant re: restaurants){
            if(re.getId() > max){
                max = re.getId();
            }
        }
        r.setId(max+1);
        restaurants.add(r);
        return r;
    }

    public Meal addMeal(Meal m) {
        m.getRestaurant().getMeals().add(m);
        return m;
    }

}
