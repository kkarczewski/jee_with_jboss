package pro.realis.lab.jboss.foodify.api;

import pro.realis.lab.jboss.foodify.model.Meal;

import java.util.Set;

/**
 * Created by xdzm on 2015-10-14.
 */
public interface OrderService {

    void add(Meal m);

    void remove(Meal m);

    Set<Meal> getOrderedMeals();

    void doit();

    void clear();

}
