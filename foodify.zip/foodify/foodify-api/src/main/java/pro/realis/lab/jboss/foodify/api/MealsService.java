package pro.realis.lab.jboss.foodify.api;

import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import java.util.List;

/**
 * Created by xdzm on 2015-10-12.
 */
public interface MealsService {

    List<Restaurant> getRestaurants();

    public Restaurant getRestaurant(Long id);

    List<Meal> getMealsForRestaurant(Long rId);

    Meal getMealById(Long mId);

    Restaurant addRestaurant(Restaurant r);

    Meal addMeal(Restaurant r, Meal m);
}
