package pro.realis.lab.jboss.foodify.api;

public interface MealsServiceRemote extends MealsService {
}
