from org.jboss.as.cli.scriptsupport import CLI
cli = CLI.newInstance()
cli.connect("admin", "passw0r$")
cli.cmd("cd /subsystem=naming")
result = cli.cmd(":jndi-view")
response = result.getResponse()
print response
cli.disconnect()
