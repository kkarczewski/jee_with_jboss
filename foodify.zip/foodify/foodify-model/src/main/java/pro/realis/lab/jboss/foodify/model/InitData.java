package pro.realis.lab.jboss.foodify.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InitData {

    private static final Restaurant SZNYCELEK = new Restaurant(1L, "Sznycelek",
            "http://2.bp.blogspot.com/-HmC8-dt5h2o/UPAPs0iX9GI/AAAAAAAAAAo/Pow6e2nDH8Y/s400/menu-sznycelek-lodz.jpg",
            "Lodz", "Narutowicza 75A");

    private static final Restaurant MEKSYK = new Restaurant(2L, "Meksyk",
            "http://lanyun.blox.pl/resource/DSCF3529_Small_400x400.jpg",
            "Krakow", "Nadbrzezie 1A");

    private static final Restaurant BAMBINO = new Restaurant(3L, "Bambino Bar",
            "https://b.zmtcdn.com/data/reviews_photos/694/d27b73a8797b438961b91e38f16e3694_1452584133.jpg",
            "Warszawa", "Siemiatycka 15b");

    static {
        new Meal(1L, "Sznycel", 12, SZNYCELEK);
        new Meal(2L, "Watrobka", 11, SZNYCELEK);
        new Meal(3L, "Golonka", 15, SZNYCELEK);
        new Meal(4L, "Pieczen wieprzowa", 12, SZNYCELEK);
        new Meal(5L, "Tortilla", 12, MEKSYK);
        new Meal(6L, "Chilli con carne", 11, MEKSYK);
        new Meal(7L, "Tacos", 7, MEKSYK);
        new Meal(8L, "Klopsy", 11, BAMBINO);
        new Meal(9L, "Pizza", 21, BAMBINO);
        new Meal(10L, "Zupa koperkowa", 6, BAMBINO);
    }

    public static List<Restaurant> getInitialRestaurantList(){
        return new ArrayList<Restaurant>(Arrays.asList(SZNYCELEK, MEKSYK, BAMBINO));
    }


}
