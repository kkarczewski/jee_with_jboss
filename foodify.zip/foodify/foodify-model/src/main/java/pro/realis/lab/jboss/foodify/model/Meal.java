package pro.realis.lab.jboss.foodify.model;

import javax.persistence.*;
import java.io.Serializable;

@NamedQueries({
        @NamedQuery(name = "Meal.SELECT_MEALS_BY_RESTAURANT",
                query = "select m from Meal m where m.restaurant=:restaurant"),
        @NamedQuery(name = "Meal.SELECT_MEAL_BY_ID",
                query = "select m from Meal m where m.id=:id")
})
@Entity
public class Meal implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private int price;

    @ManyToOne
    private Restaurant restaurant;

    public Meal(Long id, String name, int price, Restaurant servedIn) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.restaurant = servedIn;
        servedIn.getMeals().add(this);
    }

    public Meal(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Meal{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", restaurant=" + restaurant +
                '}';
    }
}
