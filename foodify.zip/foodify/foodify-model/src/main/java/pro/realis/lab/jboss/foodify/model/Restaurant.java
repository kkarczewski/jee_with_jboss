package pro.realis.lab.jboss.foodify.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



@NamedQueries(
        {
                @NamedQuery(name = "Restaurant.SELECT_ALL",
                        query = "select r from Restaurant r"),
                @NamedQuery(name = "Restaurant.SELECT_BY_ID",
                        query = "select r from Restaurant r where r.id=:id")


        })

@Entity
public class Restaurant implements Serializable {

    public Restaurant(Long id, String name, String logoImage, String city, String streetAndNumber) {
        this.id = id;
        this.name = name;
        this.logoImage = logoImage;
        this.city = city;
        this.streetAndNumber = streetAndNumber;
    }

    public Restaurant() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String logoImage;

    private String city;

    private String streetAndNumber;

    @OneToMany(mappedBy = "restaurant")
    private transient List<Meal> meals = new ArrayList<Meal>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogoImage() {
        return logoImage;
    }

    public void setLogoImage(String logoImage) {
        this.logoImage = logoImage;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreetAndNumber() {
        return streetAndNumber;
    }

    public void setStreetAndNumber(String streetAndNumber) {
        this.streetAndNumber = streetAndNumber;
    }

    public List<Meal> getMeals() {
        return meals;
    }

    public void setMeals(List<Meal> meals) {
        this.meals = meals;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Restaurant{" +
                "streetAndNumber='" + streetAndNumber + '\'' +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", logoImage='" + logoImage + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
