CREATE TABLE MEAL
(
  ID            IDENTITY,
  NAME          VARCHAR(255),
  PRICE         INTEGER NOT NULL,
  RESTAURANT_ID BIGINT
);

CREATE TABLE RESTAURANT
(
  ID              IDENTITY,
  CITY            VARCHAR(255),
  LOGOIMAGE       VARCHAR(255),
  NAME            VARCHAR(255),
  STREETANDNUMBER VARCHAR(255)
);

CREATE TABLE USERS
(
  USER_NAME     VARCHAR(15) IDENTITY,
  USER_PASS     VARCHAR(15)
);

CREATE TABLE USER_ROLES
(
  USER_NAME     VARCHAR(15),
  ROLE_NAME     VARCHAR(15),
  PRIMARY KEY (USER_NAME, ROLE_NAME)
);

INSERT INTO PUBLIC.RESTAURANT(ID, CITY, LOGOIMAGE, NAME, STREETANDNUMBER) VALUES
(2, 'London', 'http://2.bp.blogspot.com/-HmC8-dt5h2o/UPAPs0iX9GI/AAAAAAAAAAo/Pow6e2nDH8Y/s400/menu-sznycelek-lodz.jpg', 'James', 'Queens'),
(3, 'Paris', 'http://2.bp.blogspot.com/-HmC8-dt5h2o/UPAPs0iX9GI/AAAAAAAAAAo/Pow6e2nDH8Y/s400/menu-sznycelek-lodz.jpg', 'Jack', 'Chiraque');

INSERT INTO PUBLIC.MEAL(ID, NAME, PRICE, RESTAURANT_ID) VALUES
(1, 'English breakfast', 12, 2),
(2, 'Whisky in the jar', 15, 2),
(3, 'Croissant', 5, 3),
(4, 'Coffe', 3, 3);