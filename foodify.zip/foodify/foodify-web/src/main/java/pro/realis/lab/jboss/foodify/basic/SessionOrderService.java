package pro.realis.lab.jboss.foodify.basic;

import pro.realis.lab.jboss.foodify.api.OrderService;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Order;

import javax.annotation.Resource;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.jms.*;
import java.io.Serializable;
import java.util.Set;

@SessionScoped
public class SessionOrderService implements OrderService, Serializable {

    private Order o = new Order();

    @Inject
    transient JMSContext ctx;

    /* JMS 1.0 */
   /* @Resource(mappedName = "java:/JmsXA")
    private ConnectionFactory connectionFactory;

*/
    @Resource(mappedName="java:/jms/queue/orders")
    Queue queue;



    public void add(Meal m) {
        o.addMeal(m);
    }

    public void remove(Meal m) {
        o.removeMeal(m);
    }

    public Set<Meal> getOrderedMeals() {
        return o.getMeals();
    }


    public void doit() {
         /* JMS 2.0*/
         ctx.createProducer().send(queue, o);


        /* JMS 1.0 */
        /*Connection connection;
        try {
            connection = connectionFactory.createConnection();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer messageProducer = session.createProducer(queue);

            ObjectMessage message = session.createObjectMessage();
            message.setObject(o);
            messageProducer.send(message);
            o = new Order();
        } catch (JMSException e) {
            e.printStackTrace();
        }*/



    }

    public void clear() {
       o.reset();
    }
}
