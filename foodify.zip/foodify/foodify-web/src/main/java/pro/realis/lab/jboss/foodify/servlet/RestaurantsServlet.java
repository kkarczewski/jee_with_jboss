package pro.realis.lab.jboss.foodify.servlet;

import pro.realis.lab.jboss.foodify.api.MealsService;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;


public class RestaurantsServlet extends HttpServlet{

    private Logger logger = Logger.getLogger("pro.realis.lab.jboss.foodify");

    public static final String RESTAURANTS = "restaurants";

    @Inject
    private MealsService mealsService;

    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

        logger.info("about to fetch fetching restaurants");

        List<Restaurant> restaurants =  mealsService.getRestaurants();
        logger.info("fetching restaurants. " + restaurants.size() + " items found");

        req.setAttribute(RESTAURANTS, restaurants);

        req.getSession(true).getServletContext()
                .getRequestDispatcher("/WEB-INF/jsp/restaurants.jsp").forward(req, resp);

    }
}
