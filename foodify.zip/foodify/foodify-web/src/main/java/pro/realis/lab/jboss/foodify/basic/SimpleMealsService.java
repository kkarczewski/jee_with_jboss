package pro.realis.lab.jboss.foodify.basic;


import pro.realis.lab.jboss.foodify.api.MealsService;
import pro.realis.lab.jboss.foodify.dao.MealsDAO;
import pro.realis.lab.jboss.foodify.model.InitData;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import java.util.List;

@Alternative
public class SimpleMealsService implements MealsService {

    @Inject
    private MealsDAO mDao;

    private List<Restaurant> rs = InitData.getInitialRestaurantList();

    public List<Restaurant> getRestaurants() {
        return mDao.getAllRestaurants();
    }

    public Restaurant getRestaurant(Long id){
        return mDao.getRestaurantById(id);
    }

    public List<Meal> getMealsForRestaurant(Long rId) {
        Restaurant r = getRestaurant(rId);
        return mDao.getMealsByRestaurant(r);
    }

    public Meal getMealById(Long mId) {
        return mDao.getMealsById(mId);
    }

    public Restaurant addRestaurant(Restaurant r) {
        throw new UnsupportedOperationException("not implemented here");
    }

    public Meal addMeal(Restaurant r, Meal m) {
        throw new UnsupportedOperationException("not implemented here");
    }

}
