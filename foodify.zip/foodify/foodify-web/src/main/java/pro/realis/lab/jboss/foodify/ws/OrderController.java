package pro.realis.lab.jboss.foodify.ws;

import pro.realis.lab.jboss.foodify.api.MealsService;
import pro.realis.lab.jboss.foodify.api.OrderService;
import pro.realis.lab.jboss.foodify.model.Meal;


import javax.enterprise.inject.Instance;
import javax.inject.Inject;

import javax.ws.rs.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

@Path("/orderitems")
@Produces("*/*")
@Consumes("*/*")
public class OrderController implements Serializable{

    private Logger logger = Logger.getLogger(OrderController.class.getName());

    @Inject
    private Instance<OrderService> orderService;

    @Inject
    private MealsService mealService;

    @GET
    @Produces("application/json")
    public Set<MealData> getMeals(){
        logger.info("obtaining ordered meal list");
        Set<MealData> mds = new HashSet<MealData>();
        for(Meal m: orderService.get().getOrderedMeals()){
            mds.add(new MealData(m.getId(), m.getPrice(), m.getName(), m.getRestaurant().getName()));
        }
        logger.info("returning list of " +mds.size() + " ordered meals");
        return mds;
    }

    @POST
    @Path("/{id}")
    public void add(@PathParam("id") long mId){
        logger.info("adding meal " + mId + " to order");
        orderService.get().add(mealService.getMealById(mId));
    }

    @DELETE
    @Path("/{id}")
    public void remove(@PathParam("id") Long mId){
        logger.info("removing meal " + mId + " to order");
        orderService.get().remove(mealService.getMealById(mId));
    }

    @DELETE
    public String clear(){
        logger.info("reseting order");
        orderService.get().clear();
        return "success";
    }

    @POST
    public String submit(){
        logger.info("finalizing order");
        orderService.get().doit();
        return "success";
    }

    static class MealData {
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public Integer getPrice() {
            return price;
        }

        public void setPrice(Integer price) {
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getRestaurantName() {
            return restaurantName;
        }

        public void setRestaurantName(String restaurantName) {
            this.restaurantName = restaurantName;
        }

        public MealData(Long id, Integer price, String name, String restaurantName) {
            this.id = id;
            this.price = price;
            this.name = name;
            this.restaurantName = restaurantName;
        }

        private Long id;
        private Integer price;
        private String name;
        private String restaurantName;
    }
}
