package pro.realis.lab.jboss.foodify.controller;

import pro.realis.lab.jboss.foodify.api.MealsService;
import pro.realis.lab.jboss.foodify.model.Meal;
import pro.realis.lab.jboss.foodify.model.Restaurant;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.logging.Logger;

@Named
public class RestaurantsController {

    private Logger logger = Logger.getLogger("pro.realis.lab.jboss.foodify");

    @Inject
    private MealsService ms;

    //@Inject
    private HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

    public List<Restaurant> getRestaurants(){
        logger.info("fetching restaurant list");
        return ms.getRestaurants();
    }

    public Restaurant getCurrentRestaurant(){
        return ms.getRestaurant(currentRestId());
    }

    public List<Meal> getMeals(){
        Long id = currentRestId();
        logger.info("fetching meals for restaurant " + id);
        return ms.getMealsForRestaurant(currentRestId());
    }

    private Long currentRestId() {
        return Long.parseLong(req.getParameter("restaurantId"));
    }

}
